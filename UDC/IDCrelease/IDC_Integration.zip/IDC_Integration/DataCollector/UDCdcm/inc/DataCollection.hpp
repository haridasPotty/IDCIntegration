#ifndef DATA_COLLECTION_HPP
#define DATA_COLLECTION_HPP
#include "JobContainer.hpp"
#include "TaskContainer.hpp"
#include <iostream>
#include <string>







#endif